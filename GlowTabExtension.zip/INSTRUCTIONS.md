# Follow these instructions to get the extension on your browser:

- Step 1 : Extract the .zip file
- Step 2 : go to 'chrome://extensions' (it works on all browsers)
- Step 3 : Drag and drop the 'GlowTabExtension.crx' file anywhere on the page.
- Step 4 : Your extension is installed!